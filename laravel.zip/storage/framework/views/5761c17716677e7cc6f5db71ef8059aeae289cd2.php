


<?php $__env->startSection('title', 'Data Kategori'); ?>

<?php $__env->startSection('page_name', 'Data Kategori'); ?>

<?php $__env->startSection('content'); ?>


    <div class="content">
        <div class="container-fluid">



            
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                

                        <div class="card-header card-header-tabs" data-background-color="purple">
                        
                            <div class="nav nav-tabs" data-tabs="tabs">
                                <span class="nav-tabs-title"><h4 style=" text-shadow: 0 2px 5px rgba(33, 33, 33, 0.5); ">Data Kategori</h4></span>
                                <a type="button" class="btn btn-primary pull-right " href="/data_kategori/add"><i class="material-icons">add</i> Tambah Data</a>
                            </div>
                        </div>
                        

                        <div class="card-content">
                        <div class="table-responsive">
                            <table id="datatables" class="table table-bordered table-striped">
                            <thead class=" text-primary">
                                <th class="text-center">No</th>
                                <th>Nama Kategori</th>
                                <th class="text-center">Gambar Kategori</th>
                                <th class="text-center">Actions</th>
                            </thead>
                            <?php
                                $no = 1;
                            ?>
                            <tbody>   
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($no++); ?></td>
                                        <td><?php echo e($data_kategori->nama_kategori); ?></td>
                                        <td class="text-center">
                                            <img src="<?php echo e(url('img_kategori/'.$data_kategori->gambar_kategori)); ?>" style="width: 120px; height: 120px; border-radius: 10px;" class="card-img-top mb-3" alt="...">
                                        </td>
                                        
                                        <td class="td-actions text-center">
                                            <a type="button" rel="tooltip" data-placement="bottom" title="Edit Data" class="btn btn-success" href="/data_kategori/edit/<?php echo e($data_kategori->id_kategori); ?>"><i class="material-icons">edit</i></a>
                                            <a type="button" rel="tooltip" data-placement="bottom" title="Hapus Data" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data ini?')" href="/data_kategori/delete/<?php echo e($data_kategori->id_kategori); ?>"><i class="material-icons">close</i></a>
                                        </td>
                                        
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>








            
                        
                        

                        



        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpro.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/kategori/data_kategori.blade.php ENDPATH**/ ?>