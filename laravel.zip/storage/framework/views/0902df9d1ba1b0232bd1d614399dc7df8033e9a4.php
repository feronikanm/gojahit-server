


<?php $__env->startSection('title', 'Data Ukuran Detail Pesanan'); ?>

<?php $__env->startSection('page_name', 'Data Ukuran Detail Pesanan'); ?>

<?php $__env->startSection('content'); ?>
        

  <div class="content">
    <div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
        <div class="card">
            
            

            <div class="card-header card-header-tabs" data-background-color="purple">
                <h4 class="card-title">Data Ukuran Detail Pesanan</h4>
            </div>

            
            <div class="card-body">

            <div class="table-responsive">

                
                <table id="datatables" class="table">

                <thead class=" text-primary">
                    <th class="text-center">No</th>
                    <th class="text-center">ID Pesanan</th>
                    <th>Kategori</th>
                    <th>Nama Ukuran</th>
                    <th>Ukuran</th>
                    <th class="text-right">Actions</th>
                </thead>
                <?php
                    $no = 1;
                ?>
                <tbody>   
                        <tr>
                            <td class="text-center"><?php echo e($no++); ?></td>
                            <td class="text-center"></td>
                            <td></td>

                            <td></td>

                            <td></td>
                            
                            <td class="td-actions text-right"></td> 
                        </tr>
                </tbody>
                </table>
            </div>
            </div>
        </div>
        </div>
    </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpro.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/ukuran_detail_pesanan/data_ukuran_detail_pesanan.blade.php ENDPATH**/ ?>