

<?php $__env->startSection('title', 'Data Pelanggan'); ?>

<?php $__env->startSection('page_name', 'Data Pelanggan'); ?>

<?php $__env->startSection('content'); ?>
    


<div class="content">
    <div class="container-fluid">
        
        
        <div class="row">
            <div class="col-md-12">
                <div class="card">

                    <div class="card-header card-header-tabs" data-background-color="purple">
                        
                        <div class="nav nav-tabs" data-tabs="tabs">
                            <span class="nav-tabs-title"><h4 style=" text-shadow: 0 2px 5px rgba(33, 33, 33, 0.5); ">Data Pelanggan</h4></span>
                            <a type="button" class="btn btn-primary pull-right " href="/data_pelanggan/add"><i class="material-icons">add</i> Tambah Data</a>
                        </div>
                    </div>

                    <div class="card-content">
                        <div class="toolbar">
                            <!--        Here you can write extra buttons/actions for the toolbar              -->
                        </div>
                        <div class="material-datatables">
                            <table id="datatables" class="table table-bordered table-striped" cellspacing="0" width="100%" style="width:100%">
                                <thead class="text-primary">
                                    <tr>
                                        <th class="text-center">No</th>
                                        <th>Nama</th>
                                        <th>Email</th>
                                        <th>Password</th>
                                        
                                        <th>Latitude</th>
                                        <th>Longitude</th>
                                        <th>Alamat</th>
                                        
                                        
                                        <th class="disabled-sorting text-center">Actions</th>
                                    </tr>
                                </thead>

                                <?php
                                    $no = 1;
                                ?>
                                <tbody>
                                    <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($no++); ?></td>
                                        <td><?php echo e($data_pelanggan->nama_pelanggan); ?></td>
                                        <td><?php echo e($data_pelanggan->email_pelanggan); ?></td>
                                        <td><?php echo e($data_pelanggan->password_pelanggan); ?></td>
                                        
                                        <td><?php echo e($data_pelanggan->latitude_pelanggan); ?></td>
                                        <td><?php echo e($data_pelanggan->longitude_pelanggan); ?></td>
                                        <td><?php echo e($data_pelanggan->alamat_pelanggan); ?></td>
                                        
                                        
                                        

                                        <td class="td-actions text-center">
                                            
                                                <a type="button" rel="tooltip" data-placement="bottom" title="Lihat Data" class="btn btn-info" href="/data_pelanggan/show/<?php echo e($data_pelanggan->id_pelanggan); ?>"><i class="material-icons">person</i></a>
                                                <a type="button" rel="tooltip" data-placement="bottom" title="Edit Data" class="btn btn-success" href="/data_pelanggan/edit/<?php echo e($data_pelanggan->id_pelanggan); ?>"><i class="material-icons">edit</i></a>
                                                <a type="button" rel="tooltip" data-placement="bottom" title="Hapus Data" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data ini?')" href="/data_pelanggan/delete/<?php echo e($data_pelanggan->id_pelanggan); ?>"><i class="material-icons">close</i></a>
                                            
                                        </td>
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- end content-->
                </div>
                <!--  end card  -->
            </div>
            <!-- end col-md-12 -->
        </div>
        <!-- end row -->
    </div>
</div>

    

   
    
<?php $__env->stopSection(); ?>



  
<?php echo $__env->make('adminpro.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/pelanggan/data_pelanggan.blade.php ENDPATH**/ ?>