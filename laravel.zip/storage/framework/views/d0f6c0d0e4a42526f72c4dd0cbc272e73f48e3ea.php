

<?php $__env->startSection('title', 'Data Detail Kategori'); ?>

<?php $__env->startSection('page_name', 'Data Detail Kategori'); ?>

<?php $__env->startSection('content'); ?>
        

  <div class="content">
    
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-primary">
                <p class="card-category"></p>
                <h4 class="card-title ">Data Detail Ketegori</h4>
                <p class="card-category"></p>
                </div>
                <div class="card-body">
                <div class="table-responsive">
                    <table id="example1" class="table">
                    <thead class=" text-primary">
                        <th class="text-center">No</th>
                        <th>Nama Penjahit</th>
                        <th>Kategori Penjahit</th>
                        <th>Keterangan Kategori</th>
                        <th>Bahan</th>
                        <th>Harga Bahan</th>
                        <th>Ongkos Penjahit</th>
                        <th>Perkiraan Lama Waktu</th>
                        <th class="text-right">Actions</th>
                    </thead>
                    <?php
                        $no = 1;
                    ?>
                    <tbody>   
                        <?php $__currentLoopData = $penjahit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_penjahit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($no++); ?></td>
                                
                                <td><?php echo e($data_penjahit->nama_penjahit); ?></td>
                                
                                <td>
                                        <?php $__currentLoopData = $data_penjahit->tbl_kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <?php echo e($data_kategori->nama_kategori); ?>    
                                            </li>         
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <?php $__currentLoopData = $data_penjahit->tbl_detail_kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_detail_kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <?php echo e($data_detail_kategori->keterangan_kategori); ?>    
                                    </li>            
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <?php $__currentLoopData = $data_penjahit->tbl_detail_kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_detail_kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <?php echo e($data_detail_kategori->bahan_jahit); ?>    
                                    </li>            
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <?php $__currentLoopData = $data_penjahit->tbl_detail_kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_detail_kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <?php echo e($data_detail_kategori->harga_bahan); ?>    
                                    </li>            
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <?php $__currentLoopData = $data_penjahit->tbl_detail_kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_detail_kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <?php echo e($data_detail_kategori->ongkos_penjahit); ?>    
                                    </li>            
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <?php $__currentLoopData = $data_penjahit->tbl_detail_kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_detail_kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <?php echo e($data_detail_kategori->perkiraan_lama_waktu_pengerjaan); ?>    
                                    </li>            
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>

                                <td class="td-actions text-right">
                                    <?php $__currentLoopData = $data_penjahit->tbl_detail_kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_detail_kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <form action="#" method="POST">
                                        <button type="button" rel="tooltip" class="btn btn-info">
                                            <i class="material-icons">person</i>
                                        </button>
                                        <button type="button" rel="tooltip" class="btn btn-success">
                                            <i class="material-icons">edit</i>
                                        </button>
                                        <button type="button" rel="tooltip" class="btn btn-danger">
                                            <i class="material-icons">close</i>
                                        </button>
                                    </form>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td> 
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>

        


        


  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlayouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/data_detail_kategori.blade.php ENDPATH**/ ?>