

<?php $__env->startSection('title', 'Data Ukuran'); ?>

<?php $__env->startSection('page_name', 'Ukuran'); ?>

<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-primary">
                <p class="card-category"></p>
                <h4 class="card-title ">Data Ukuran</h4>
                <p class="card-category"></p>
                <a type="button" class="btn btn-primary pull-right" href="/data_ukuran/add"><i class="material-icons">add</i> Tambah Data</a>
                
                </div>
                <div class="card-body">
                <div class="table-responsive">
                    <table id="example1" class="table">
                    <thead class=" text-primary">
                        <th class="text-center">No</th>
                        
                        <th>Nama Ukuran</th>
                        <th>Gambar Ukuran</th>
                        <th class="text-right">Actions</th>
                    </thead>
                    <?php
                        $no = 1;
                    ?>
                    <tbody>   
                        <?php $__currentLoopData = $ukuran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_ukuran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                            <tr>
                                <td class="text-center"><?php echo e($no++); ?></td>
                                <td><?php echo e($data_ukuran->nama_ukuran); ?></td>
                                <td><?php echo e($data_ukuran->gambar_ukuran); ?></td>
  
                                <td class="td-actions text-right">
                                    <form action="#" method="POST">
                                        <button type="button" rel="tooltip" class="btn btn-success">
                                            <i class="material-icons">edit</i>
                                        </button>
                                        <button type="button" rel="tooltip" class="btn btn-danger">
                                            <i class="material-icons">close</i>
                                        </button>
                                    </form>
                                </td>
                                
                            </tr>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlayouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/data_ukuran.blade.php ENDPATH**/ ?>