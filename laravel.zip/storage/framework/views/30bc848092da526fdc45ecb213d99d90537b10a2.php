


<?php $__env->startSection('title', 'Data Penjahit'); ?>

<?php $__env->startSection('page_name', 'Data Penjahit'); ?>

<?php $__env->startSection('content'); ?>
    
<div class="content">
    <div class="container-fluid">

      <div class="row">
        <div class="col-md-12">
          <div class="card card-profile">
            <div class="card-avatar">
              <a href="javascript:;">
      
                <img class="img" src="<?php echo e(url('img_penjahit/'.$data->foto_penjahit)); ?>" style="width: 130px; height: 130px;" />
              </a>
            </div>
            
            <div class="card-body">
              <h6 class="card-category  text-primary">Nama Toko</h6>
              <h4 class="card-title"><?php echo e($data->nama_toko); ?></h4>
                
            </div>

          </div>
        </div>
      </div>


      
      <div class="row">

        <div class="col-md-6">
          <div class="card">

            
            

            <div class="card-header card-header-tabs" data-background-color="purple">
              <h4 class="card-title">Detail Data</h4>
            </div>

            
            <div class="card-content">
       
              <div class="card-content table-responsive table-full-width" style="margin-left: 50px">
                <div class="row">
                  <label class="col-sm-4 col-form-label text-primary "><?php echo e(__('ID Penjahit')); ?></label>
                  <div class="col-sm-8"><?php echo e($data->id_penjahit); ?></div>
                </div>

                <div class="row">
                  <label class="col-sm-4 col-form-label text-primary"><?php echo e(__('Nama Penjahit')); ?></label>
                  <div class="col-sm-8"><?php echo e($data->nama_penjahit); ?></div>
                </div>
                
                <div class="row">
                  <label class="col-sm-4 col-form-label text-primary"><?php echo e(__('Email')); ?></label>
                  <div class="col-sm-8"><?php echo e($data->email_penjahit); ?></div>
                </div>

                <div class="row">
                  <label class="col-sm-4 col-form-label text-primary"><?php echo e(__('Password')); ?></label>
                  <div class="col-sm-8"><?php echo e($data->password_penjahit); ?></div>
                </div>

                <div class="row">
                  <label class="col-sm-4 col-form-label text-primary"><?php echo e(__('No. Telp')); ?></label>
                  <div class="col-sm-8"><?php echo e($data->telp_penjahit); ?></div>
                </div>

                <div class="row">
                  <label class="col-sm-4 col-form-label text-primary"><?php echo e(__('Nama Toko')); ?></label>
                  <div class="col-sm-8"><?php echo e($data->nama_toko); ?></div>
                </div>
      
                <div class="row">
                  <label class="col-sm-4 col-form-label text-primary"><?php echo e(__('Keterangan Toko')); ?></label>
                  <div class="col-sm-8"><?php echo e($data->keterangan_toko); ?></div>
                </div>
      
                <div class="row">
                  <label class="col-sm-4 col-form-label text-primary"><?php echo e(__('Latitude')); ?></label>
                  <div class="col-sm-8"><?php echo e($data->latitude_penjahit); ?></div>
                </div>
      
                <div class="row">
                  <label class="col-sm-4 col-form-label text-primary"><?php echo e(__('Longitude')); ?></label>
                  <div class="col-sm-8"><?php echo e($data->longitude_penjahit); ?></div>
                </div>

                <div class="row">
                  <label class="col-sm-4 col-form-label text-primary"><?php echo e(__('Alamat')); ?></label>
                  <div class="col-sm-8"><?php echo e($data->alamat_penjahit); ?></div>
                </div>

                <div class="row">
                  <label class="col-sm-4 col-form-label text-primary"><?php echo e(__('Spesifikasi Penjahit')); ?></label>
                  <div class="col-sm-8"><?php echo e($data->spesifikasi_penjahit); ?></div>
                </div>

                <div class="row">
                  <label class="col-sm-4 col-form-label text-primary"><?php echo e(__('Jangkauan Kategori Penjahit')); ?></label>
                  <div class="col-sm-8"><?php echo e($data->jangkauan_kategori_penjahit); ?></div>
                </div>

                

                

                <div class="row">
                  <label class="col-sm-4 col-form-label text-primary"><?php echo e(__('Jam Buka')); ?></label>
                  <div class="col-sm-8"><?php echo e($data->jam_buka); ?></div>
                </div>

                <div class="row">
                  <label class="col-sm-4 col-form-label text-primary"><?php echo e(__('Jam Tutup')); ?></label>
                  <div class="col-sm-8"><?php echo e($data->jam_tutup); ?></div>
                </div>

                

              </div>

              <div class="form-footer text-right" style="margin-bottom: 60px">
                <a type="button" class="btn btn-primary pull-right" href="/data_penjahit/edit/<?php echo e($data->id_penjahit); ?>">Update Data</a>
                <a type="button" class="btn btn-white pull-right" href="/data_penjahit">Kembali</a>
              </div>

              
              

            </div>
          </div>
        </div>


        

        <div class="col-md-6">
          <div class="card">
            
            

            <div class="card-header card-header-tabs" data-background-color="purple">
                        
              <div class="nav nav-tabs" data-tabs="tabs">
                  <span class="nav-tabs-title"><h4>Ketegori</h4></span>
                  <a type="button" class="btn btn-primary pull-right " href="/data_penjahit/show/kategori/add/<?php echo e($data->id_penjahit); ?>"><i class="material-icons">add</i> Tambah Data</a>
              </div>
          </div>
            
            
            

            
            <div class="card-content">
              <div class="table-responsive">
                <table id="example1" class="table table-bordered table-striped ">
                    <thead class="text-primary" >
                        <th class="text-center">No</th>
                        <th>Kategori</th>
                        <th class="text-center">Gambar Kategori</th>
                        <th class="text-center">Action</th>
                    </thead>
                    <?php
                        $no = 1;
                    ?>
                    <tbody>   
                        <?php $__currentLoopData = $kategori_penjahit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($no++); ?></td>
                                <td><?php echo e($kategori->nama_kategori); ?></td>
                                <td class="text-center">
                                    <img src="<?php echo e(url('img_kategori/'.$kategori->gambar_kategori)); ?>" style="width: 120px; height: 120px; border-radius: 10px;" class="card-img-top mb-3" alt="...">
                                </td>  
                                <td class="td-actions text-center">
                                  <a type="button" rel="tooltip" data-placement="bottom" title="Lihat Data" class="btn btn-info" href="/data_penjahit/show/ukuran/<?php echo e($kategori->id_detail_kategori); ?>"><i class="material-icons">trending_flat</i></a>
                                  <a type="button" rel="tooltip" data-placement="bottom" title="Edit Data" class="btn btn-success" href="/data_penjahit/show/kategori/edit/<?php echo e($kategori->id_detail_kategori); ?>"><i class="material-icons">edit</i></a>
                                  <a type="button" rel="tooltip" data-placement="bottom" title="Hapus Data" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data ini?')" href="/data_penjahit/show/kategori/delete/<?php echo e($kategori->id_detail_kategori); ?>"><i class="material-icons">close</i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table> 
            </div>
            </div>
          </div>
        </div>

      

      
        <div class="col-md-6">
          <div class="card">


            

            <div class="card-header card-header-tabs" data-background-color="purple">
              <h4 class="card-title">Data Pesanan</h4>
            </div>


            
            <div class="card-content">
              <div class="table-responsive">
                <table id="example1" class="table table-bordered table-striped ">
                    <thead class="text-primary" >
                        <th class="text-center">ID Pesanan</th>
                        <th>Nama Pelanggan</th>
                        <th>Tanggal Pesanan</th>
                        <th>Tanggal Pesanan Selesai</th>
                        <th>Status Pesanan</th>
                    </thead>
                    <?php
                        $no = 1;
                    ?>
                    <tbody>   
                        <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td class="text-center"><?php echo e($data_pesanan->id_pesanan); ?></td>
                              <td><?php echo e($data_pesanan->nama_pelanggan); ?></td>
                              <td><?php echo e($data_pesanan->tanggal_pesanan); ?></td>
                              <td><?php echo e($data_pesanan->tanggal_pesanan_selesai); ?></td>
                              <td><?php echo e($data_pesanan->status_pesanan); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table> 
            </div>
            </div>
          </div>
        </div>
      </div>
    
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpro.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/penjahit/show_data_penjahit.blade.php ENDPATH**/ ?>