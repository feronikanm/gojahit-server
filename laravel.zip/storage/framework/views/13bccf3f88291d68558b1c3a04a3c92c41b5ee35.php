


<?php $__env->startSection('title', 'Detail Data'); ?>

<?php $__env->startSection('page_name', 'Detail Data'); ?>

<?php $__env->startSection('content'); ?>
    

        
    <div class="content">
        <div class="container-fluid">

          <?php $__currentLoopData = $kategori_penjahit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

   
          <div class="row">
            <div class="col-md-12">
            <div class="card">


                
                <div class="card-header card-header-tabs" data-background-color="purple">
                    <h4 class="card-title ">Data Penjahit</h4>
                </div>

                

                
                <div class="card-content">

                <div class="table-responsive">
                    
                    <table class="table table-bordered table-striped">
                        <thead class=" text-primary">
                        <th>Nama Penjahit</th>
                        <th>Nama Toko</th>
                        <th>Alamat Toko</th>
                    </thead>
                    <tbody>   
                            <tr>
                                <td><?php echo e($kategori->nama_penjahit); ?></td>
                                <td><?php echo e($kategori->nama_toko); ?></td>                                
                                <td><?php echo e($kategori->alamat_penjahit); ?></td>                                
                            </tr>
                    </tbody>
                    </table>
                </div>
                </div>
            </div>
            </div>
        </div>


        <div class="row">
            <div class="col-md-12">
            <div class="card">
  

                <div class="card-header card-header-tabs" data-background-color="purple">
                        
                    <div class="nav nav-tabs" data-tabs="tabs">
                        <span class="nav-tabs-title"><h4 style=" text-shadow: 0 2px 5px rgba(33, 33, 33, 0.5); ">Detail Kategori</h4></span>
                        <a type="button" class="btn btn-primary pull-right " onclick="return confirm('Yakin ingin menghapus data ini?')"  href="/data_detail_kategori/delete/<?php echo e($kategori->id_detail_kategori); ?>"><i class="material-icons">delete</i> Detele</a>
                        <a type="button" class="btn btn-primary pull-right " href="/data_detail_kategori/edit/<?php echo e($kategori->id_detail_kategori); ?>"><i class="material-icons">edit</i> Edit</a>
                    </div>
                </div>

                


                
                <div class="card-content">
                <div class="table-responsive">
                    
                    <table class="table table-bordered table-striped">
                    <thead class=" text-primary">
                        <th>Nama Kategori</th>
                        <th>Keterangan</th>
                        <th>Bahan Jahit</th>
                        <th>Harga Bahan (Rp)</th>
                        <th>Ongkos Jahit (Rp)</th>
                        <th>Lama Pengerjaan (Hari)</th>
                        
                        
                    </thead>
                    <?php
                        $no = 1;
                    ?>
                    <tbody>   
                            <tr>
                                
                                <td><?php echo e($kategori->nama_kategori); ?></td>
                                <td><?php echo e($kategori->keterangan_kategori); ?></td>
                                <td><?php echo e($kategori->bahan_jahit); ?></td>
                                <td><?php echo e($kategori->harga_bahan); ?></td>
                                <td><?php echo e($kategori->ongkos_penjahit); ?></td>
                                <td><?php echo e($kategori->perkiraan_lama_waktu_pengerjaan); ?></td>


                                
                                    
                                    
                                
                                
                            </tr>
                      </tbody>
                    </table>
                </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            </div>
        </div>


        <div class="row">
            <div class="col-md-12">
            <div class="card">


                <div class="card-header card-header-tabs" data-background-color="purple">
                        
                    <div class="nav nav-tabs" data-tabs="tabs">
                        <span class="nav-tabs-title"><h4 style=" text-shadow: 0 2px 5px rgba(33, 33, 33, 0.5); ">Detail Ukuran</h4></span>
                        
                        <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#exampleModal"><i class="material-icons">add</i> Tambah Data</button>

                    </div>
                </div>


                

                
                <div class="card-content">

                <div class="table-responsive">
                    
                    <table class="table table-bordered table-striped">
                        <thead class=" text-primary">
                        <th>Nama Ukuran</th>
                        <th class="text-center">Gambar Ukuran</th>
                        <th class="text-center">Actions</th>
                    </thead>
                    <?php
                        $no = 1;
                    ?>
                    <tbody>   
                        <?php $__currentLoopData = $ukuran_kategori_penjahit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ukuran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($ukuran->nama_ukuran); ?></td>
                                
                                <td class="text-center">
                                    <img src="<?php echo e(url('img_ukuran/'.$ukuran->gambar_ukuran)); ?>" style="width: 120px; height: 120px; border-radius: 20px;" class="card-img-top mb-3" alt="...">
                                </td>
                                <td class="td-actions text-center">
                                    
                                    <a type="button" rel="tooltip" data-placement="bottom" title="Hapus Data" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data ini?')" href="/data_detail_kategori/ukuran/delete/<?php echo e($ukuran->id_ukuran_detail_kategori); ?>"><i class="material-icons">close</i></a>
                                </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
                </div>
            </div>
            </div>
        </div>

        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Data Ukuran</h5>
            
            </div>
            <div class="modal-body">

                <form method="post" action="/data_detail_kategori/ukuran/store" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>


                    <?php $__currentLoopData = $kategori_penjahit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="hidden" name="id_detail_kategori" id="id_detail_kategori" value="<?php echo e($kategori->id_detail_kategori); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    

                    <div>
                    
                        <div class="form-group" id="exampleFormControlSelect1" >
                        <select class="selectpicker" data-style="btn btn-primary btn-round" title="Pilih Ukuran" name="id_ukuran">
                            <?php $__currentLoopData = $ukurans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_ukuran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data_ukuran->id_ukuran); ?>"><?php echo e($data_ukuran->nama_ukuran); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                      </div>
            
                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-simple" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary btn-simple">Tambah Data</button>
                    </div>
                </form>

        </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpro.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/detail_kategori/show_detail_kategori_ukuran.blade.php ENDPATH**/ ?>