

<?php $__env->startSection('title', 'Data Penilaian'); ?>

<?php $__env->startSection('page_name', 'Data Penilaian'); ?>

<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">

                        <div class="card-header card-header-tabs" data-background-color="purple">
                            <h4 class="card-title ">Data Penilaian</h4>
                        </div>

                        <div class="card-content">
                            <div class="table-responsive">
                                <table id="datatables" class="table table-bordered table-striped">
                                    <thead class="text-primary">
                                        <th class="text-center" style="border-bottom: 1px solid rgb(117, 0, 146);">No</th>
                                        <th class="text-center" style="border-bottom: 1px solid rgb(117, 0, 146);">ID Penjahit</th>
                                        <th class="text-center" style="border-bottom: 1px solid rgb(117, 0, 146);">Nama Penjahit</th>
                                        <th class="text-center" style="border-bottom: 1px solid rgb(117, 0, 146);">Nilai Akhir</th>
                                    </thead>
                                    <?php
                                        $no = 1;
                                    ?>
                                    <tbody>   
                                        <?php $__currentLoopData = $penilaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_penilaian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($no++); ?></td>
                                                <td class="text-center"><?php echo e($data_penilaian->id_penjahit); ?></td>                                
                                                <td class="text-center"><?php echo e($data_penilaian->nama_penjahit); ?></td>
                                                <td class="text-center"><?php echo e($data_penilaian->nilai_akhir); ?></td>      
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpro.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/nilai/data_nilai.blade.php ENDPATH**/ ?>