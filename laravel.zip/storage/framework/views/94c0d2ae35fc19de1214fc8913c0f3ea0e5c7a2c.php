


<?php $__env->startSection('title', 'Data Pelanggan'); ?>

<?php $__env->startSection('page_name', 'Data Pelanggan'); ?>

<?php $__env->startSection('content'); ?>
    
<div class="content">
    <div class="container-fluid">


      <div class="row">
        <div class="col-md-6">
          <div class="card card-profile">
            <div class="card-avatar">
              <a href="javascript:;">
      
                
                <img class="img" src="<?php echo e(url('img_pelanggan/'.$data->foto_pelanggan)); ?>" style="width: 130px; height: 130px;" />
              </a>
            </div>
            
            <div class="card-body">
              <h6 class="card-category text-primary">Nama Pelanggan</h6>
              <h4 class="card-title"><?php echo e($data->nama_pelanggan); ?></h4>
              <p class="card-description"><?php echo e($data->email_pelanggan); ?></p>  
            
            </div>

          </div>
    </div>
  </div>




  <div class="row">
    <div class="col-md-6">
      <div class="card">
              <div class="card-header card-header-tabs" data-background-color="purple">
                  <h4 class="card-title">Detail Data</h4>
              </div>
              <div class="card-content">
                
                <div class="card-content table-responsive table-full-width" style="margin-left: 50px">
                  <div class="row">
                    <label class="col-sm-3 col-form-label text-primary"><?php echo e(__('ID Pelanggan')); ?></label>
                    <div class="col-sm-5"><?php echo e($data->id_pelanggan); ?></div>
                  </div>
        
                  <div class="row">
                    <label class="col-sm-3 col-form-label text-primary"><?php echo e(__('Nama')); ?></label>
                    <div class="col-sm-5"><?php echo e($data->nama_pelanggan); ?></div>
                  </div>
                  
                  <div class="row">
                    <label class="col-sm-3 col-form-label text-primary"><?php echo e(__('Email')); ?></label>
                    <div class="col-sm-5"><?php echo e($data->email_pelanggan); ?></div>
                  </div>
        
                  <div class="row">
                    <label class="col-sm-3 col-form-label text-primary"><?php echo e(__('Password')); ?></label>
                    <div class="col-sm-5"><?php echo e($data->password_pelanggan); ?></div>
                  </div>
        
                  <div class="row">
                    <label class="col-sm-3 col-form-label text-primary"><?php echo e(__('No. Telp')); ?></label>
                    <div class="col-sm-5"><?php echo e($data->telp_pelanggan); ?></div>
                  </div>
        
                  <div class="row">
                    <label class="col-sm-3 col-form-label text-primary"><?php echo e(__('Latitude')); ?></label>
                    <div class="col-sm-5"><?php echo e($data->latitude_pelanggan); ?></div>
                  </div>
        
                  <div class="row">
                    <label class="col-sm-3 col-form-label text-primary"><?php echo e(__('Longitude')); ?></label>
                    <div class="col-sm-5"><?php echo e($data->longitude_pelanggan); ?></div>
                  </div>
        
                  <div class="row">
                    <label class="col-sm-3 col-form-label text-primary"><?php echo e(__('Alamat')); ?></label>
                    <div class="col-sm-5"><?php echo e($data->alamat_pelanggan); ?></div>
                  </div>
        
                  <div class="row">
                    <label class="col-sm-3 col-form-label text-primary"><?php echo e(__('Jenis Kelamin')); ?></label>
                    <div class="col-sm-5"><?php echo e($data->jk_pelanggan); ?></div>
                  </div>
        
                </div>
      

                
                <div class="form-footer text-right" style="margin-bottom: 60px">
                  <a type="button" class="btn btn-primary pull-right" href="/data_pelanggan/edit/<?php echo e($data->id_pelanggan); ?>">Update Data</a>
                  <a type="button" class="btn btn-white pull-right" href="/data_pelanggan">Kembali</a>
                  
                  
                </div>
                                
              </div>
              </div>
      </div>
  



    <div class="col-md-6">
      <div class="card">
          
        <div class="card-header card-header-tabs" data-background-color="purple">
          <h4 class="card-title">Data Pesanan</h4>
      </div>

          <div class="card-content">
              <div class="material-datatables">
                  <table class="table table-bordered table-striped" cellspacing="0" width="100%" style="width:100%">
                      <thead class="text-primary">
                          <tr>
                            <th class="text-center">ID Pesanan</th>
                            <th>Nama Penjahit</th>
                            <th>Tanggal Pesanan</th>
                            <th>Tanggal Pesanan Selesai</th>
                            <th>Status Pesanan</th>
                          </tr>
                      </thead>

                      <?php
                          $no = 1;
                      ?>
                      <tbody>
                        <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td class="text-center"><?php echo e($data_pesanan->id_pesanan); ?></td>
                          <td><?php echo e($data_pesanan->nama_penjahit); ?></td>
                          <td><?php echo e($data_pesanan->tanggal_pesanan); ?></td>
                          <td><?php echo e($data_pesanan->tanggal_pesanan_selesai); ?></td>
                          <td><?php echo e($data_pesanan->status_pesanan); ?></td> 
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              </div>
          </div>
          <!-- end content-->
      </div>
      <!--  end card  -->
  </div>

  </div>


 



      



    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpro.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/pelanggan/show_data_pelanggan.blade.php ENDPATH**/ ?>