


<?php $__env->startSection('title', 'Tambah Data Utilitas'); ?>

<?php $__env->startSection('page_name', 'Tambah Data Utilitas'); ?>

<?php $__env->startSection('content'); ?>
        

  <div class="content">
    <div class="container-fluid">


      <div class="row">
        <div class="col-md-8">
          <div class="card">

              <div class="card-header card-header-tabs" data-background-color="purple">
                  <h4 class="card-title ">Tambah Data Utilitas</h4>
              </div>
          
                <form method="post" action="/data_utilitas/store" enctype="multipart/form-data" class="form-horizontal">
                  <?php echo e(csrf_field()); ?>



                  <div class="card-content">

                    <div class="row">
                      <label class="col-sm-2 label-on-left">Nama Utilitas</label>
                      <div class="col-sm-7">
                          <div class="form-group label-floating is-empty">
                              <input class="form-control" name="nama_utilitas" type="text" placeholder="Nama Utilitas"  autofocus />
                          </div>
                      </div>
                    </div>

                    <div class="form-footer text-right">
                      <div class="checkbox pull-left">
                        <div class="category form-category">
                        </div>
                      </div>
                      <a type="button" class="btn btn-white pull-fill" href="/data_utilitas">Kembali</a>
                      <button type="submit" class="btn btn-primary pull-fill">Simpan</button>
                    </div>  
      
                  </div>                              
                </form>  
            </div>
          </div>
        </div>

        
    
    
    
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpro.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/utilitas/add_data_utilitas.blade.php ENDPATH**/ ?>