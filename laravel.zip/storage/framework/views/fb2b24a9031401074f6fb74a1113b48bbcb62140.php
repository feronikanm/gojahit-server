<footer class="footer">
    <div class="container-fluid">
        
        <p class="copyright pull-right">
            GoJahit
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>
            Develop by
            <a href="https://github.com/feronikanm" target="_blank">FNM</a>
        </p>
    </div>
</footer><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/adminpro/footer.blade.php ENDPATH**/ ?>