


<?php $__env->startSection('title', 'Tambah Data Kriteria'); ?>

<?php $__env->startSection('page_name', 'Tambah Data Kriteria'); ?>

<?php $__env->startSection('content'); ?>
        

  <div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
            <div class="card">


                  <div class="card-header card-header-tabs" data-background-color="purple">
                    <h4 class="card-title ">Tambah Data Kriteria</h4>
                  </div>

                
                <div class="card-content">
      

                    <form method="post" action="/data_kriteria/store" class="form-horizontal">
                      <?php echo csrf_field(); ?>
                        

                        
                       
                          <div class="row">
                            <label class="col-sm-2 label-on-left">Nama Kriteria</label>
                            <div class="col-sm-7">
                                <div class="form-group label-floating is-empty">
                                    <input class="form-control" name="nama_kriteria" type="text" placeholder="Nama Kriteria"  autofocus />
                                </div>
                            </div>
                          </div>

                          

                        <div class="row">
                          <label class="col-sm-2 label-on-left">Bobot Kriteria</label>
                          <div class="col-sm-7">
                              <div class="form-group label-floating is-empty">
                                  <input class="form-control" name="bobot_kriteria" type="number" placeholder="Nama Ukuran" />
                              </div>
                          </div>
                        </div>
                      
                          
                        

                        
                      
                        <div class="form-footer text-right">
                          <div class="checkbox pull-left">
                            <div class="category form-category">
                            </div>
                          </div>
                          <a type="button" class="btn btn-white pull-fill" href="/data_kriteria">Kembali</a>
                          <button type="submit" class="btn btn-primary pull-fill">Simpan</button>
                        </div>  


                      </form>
                      

                </div>
            </div>
            </div>
        </div>
        </div>

  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpro.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/kriteria/add_data_kriteria.blade.php ENDPATH**/ ?>