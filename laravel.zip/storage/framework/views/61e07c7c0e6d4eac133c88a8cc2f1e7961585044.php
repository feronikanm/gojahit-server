

<?php $__env->startSection('title', 'Data Penjahit'); ?>

<?php $__env->startSection('page_name', 'Penjahit'); ?>

<?php $__env->startSection('content'); ?>
    

        
    <div class="content">
        <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-primary">
                <p class="card-category"></p>
                <h4 class="card-title ">Data Penjahit</h4>
                <p class="card-category"></p>
                </div>
                <div class="card-body">
                <div class="table-responsive">
                    <table id="example1" class="table">
                    <thead class=" text-primary">
                        <th class="text-center">No</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Telp</th>
                        <th>Nama Toko</th>
                        <th>Keterangan Toko</th>
                        <th>Latitude</th>
                        <th>Longitude</th>
                        <th>Alamat</th>
                        <th>Spesifikasi Penjahit</th>
                        <th>Jangkauan Kategori Penjahit</th>
                        <th>Hari Buka</th>
                        <th>Jam Buka</th>
                        <th>Jam Tutup</th>
                        <th class="text-center">Foto</th>
                        <th class="text-right">Actions</th>
                    </thead>
                    <?php
                        $no = 1;
                    ?>
                    <tbody>   
                        <?php $__currentLoopData = $penjahit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_penjahit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($data_penjahit->nama_penjahit); ?></td>
                                <td><?php echo e($data_penjahit->email_penjahit); ?></td>
                                <td><?php echo e($data_penjahit->password_penjahit); ?></td>
                                <td><?php echo e($data_penjahit->telp_penjahit); ?></td>
                                <td><?php echo e($data_penjahit->nama_toko); ?></td>
                                <td><?php echo e($data_penjahit->keterangan_toko); ?></td>
                                <td><?php echo e($data_penjahit->latitude_penjahit); ?></td>
                                <td><?php echo e($data_penjahit->longitude_penjahit); ?></td>
                                <td><?php echo e($data_penjahit->alamat_penjahit); ?></td>
                                <td><?php echo e($data_penjahit->spesifikasi_penjahit); ?></td>
                                <td><?php echo e($data_penjahit->jangkauan_kategori_penjahit); ?></td>
                                <td><?php echo e($data_penjahit->hari_buka); ?></td>
                                <td><?php echo e($data_penjahit->jam_buka); ?></td>
                                <td><?php echo e($data_penjahit->jam_tutup); ?></td>
                                <td class="text-center"><?php echo e($data_penjahit->foto_penjahit); ?></td>
                                
                                <td class="td-actions text-right">
                                    <a type="button" rel="tooltip" data-placement="left" title="Lihat Data" class="btn btn-info" href="/data_penjahit/show/<?php echo e($data_penjahit->id_penjahit); ?>"><i class="material-icons">person</i></a>
                                    <br>
                                    <a type="button" rel="tooltip" data-placement="left" title="Edit Data" class="btn btn-success" href="/data_penjahit/edit/<?php echo e($data_penjahit->id_penjahit); ?>"><i class="material-icons">edit</i></a>
                                    <br>
                                    <a type="button" rel="tooltip" data-placement="left" title="Hapus Data" class="btn btn-danger" href="/data_penjahit/delete/<?php echo e($data_penjahit->id_penjahit); ?>"><i class="material-icons">close</i></a>
                                </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlayouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/data_penjahit.blade.php ENDPATH**/ ?>