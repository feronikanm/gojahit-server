

<?php $__env->startSection('title', 'Data Kriteria'); ?>

<?php $__env->startSection('page_name', 'Data Kriteria'); ?>

<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">

                        <div class="card-header card-header-tabs" data-background-color="purple">
                            <div class="nav nav-tabs" data-tabs="tabs">
                                <span class="nav-tabs-title"><h4 style=" text-shadow: 0 2px 5px rgba(33, 33, 33, 0.5); ">Data Kriteria</h4></span>
                                <a type="button" class="btn btn-primary pull-right " href="/data_kriteria/add"><i class="material-icons">add</i> Tambah Data</a>
                            </div>
                        </div>

                        <div class="card-content">
                            <div class="table-responsive">
                                <table id="datatables" class="table table-bordered table-striped">
                                    <thead class="text-primary">
                                        <th class="text-center" style="border-bottom: 1px solid rgb(117, 0, 146);">No</th>
                                        <th style="border-bottom: 1px solid rgb(117, 0, 146);">Nama Kriteria</th>
                                        <th class="text-center" style="border-bottom: 1px solid rgb(117, 0, 146);">Bobot Kriteria</th>
                                        <th class="text-center" style="border-bottom: 1px solid rgb(117, 0, 146);">Normalisasi Bobot Kriteria</th>
                                        <th class="text-center" style="border-bottom: 1px solid rgb(117, 0, 146);">Actions</th>
                                    </thead>
                                    <?php
                                        $no = 1;
                                    ?>
                                    <tbody>   
                                        <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center"><?php echo e($no++); ?></td>
                                                <td><?php echo e($data_kriteria->nama_kriteria); ?></td>
                                                <td class="text-center"><?php echo e($data_kriteria->bobot_kriteria); ?></td>                                
                                                <td class="text-center"><?php echo e($data_kriteria->normalisasi); ?></td>
                                                <td class="td-actions text-center">
                                                    <a type="button" rel="tooltip" data-placement="bottom" title="Edit Data" class="btn btn-success" href="/data_kriteria/edit/<?php echo e($data_kriteria->id_kriteria); ?>"><i class="material-icons">edit</i></a>
                                                </td>        
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <thead>
                                                <th class="text-center text-primary" style="border-top: 1px solid rgb(117, 0, 146);" colspan="2">Total</th>
                                                <th class="text-center text-primary" style="border-top: 1px solid rgb(117, 0, 146);"><?php echo e($total_bobot_kriteria); ?></th>
                                                <th class="text-center text-primary" style="border-top: 1px solid rgb(117, 0, 146);"></th>
                                                <th class="text-center text-primary" style="border-top: 1px solid rgb(117, 0, 146);"></th>
                                            </thead>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpro.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/kriteria/data_kriteria.blade.php ENDPATH**/ ?>