

<?php $__env->startSection('title', 'Edit Data Utilitas'); ?>

<?php $__env->startSection('page_name', 'Edit Data Utilitas'); ?>

<?php $__env->startSection('content'); ?>
        

  <div class="content">
    
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
            <div class="card">
                <div class="card-header card-header-primary">
                <p class="card-category"></p>
                <h4 class="card-title ">Edit Data Utilitas</h4>
                <p class="card-category"></p>
                </div>
                <div class="card-body">
      

                    <form method="post" action="/data_utilitas/update/<?php echo e($data->id_utilitas); ?>">
                      <?php echo csrf_field(); ?>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Nama Utilitas</label>
                          <input type="text" class="form-control" name="nama_utilitas"  value="<?php echo e($data->nama_utilitas); ?>">
                        </div>
                      
                          
                        <button type="submit" class="btn btn-primary pull-right">Simpan</button>
                        
                        <a type="button" class="btn btn-secondary pull-right" href="/data_utilitas">Kembali</a>
                        
                      </form>
                      

                </div>
            </div>
            </div>
        </div>
        </div>

  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlayouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/edit_data_utilitas.blade.php ENDPATH**/ ?>