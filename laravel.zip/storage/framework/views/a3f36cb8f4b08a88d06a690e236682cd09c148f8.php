


<?php $__env->startSection('title', 'Edit Data Penjahit'); ?>

<?php $__env->startSection('page_name', 'Edit Data Penjahit'); ?>

<?php $__env->startSection('content'); ?>
    
<div class="content">
    <div class="container-fluid">  

      <div class="row">
        <div class="col-md-8">
          <div class="card">

            

            <div class="card-header card-header-tabs" data-background-color="purple">
              <h4 class="card-title">Edit Data Penjahit</h4>
            </div>

            <form method="post" action="/data_penjahit/update/<?php echo e($data->id_penjahit); ?>"  enctype="multipart/form-data" class="form-horizontal">
              <?php echo e(csrf_field()); ?>


              <div class="card-content">
                  
                <input type="hidden" name="id_penjahit" id="id_penjahit" value="<?php echo e($data->id_penjahit); ?>">


                <div class="row">
                    <label class="col-sm-2 label-on-left">Nama</label>
                    <div class="col-sm-7">
                        <div class="form-group label-floating is-empty">
                            <input class="form-control" name="nama_penjahit" type="text" placeholder="Nama Penjahit" value="<?php echo e($data->nama_penjahit); ?>"  autofocus />
                        </div>
                    </div>
                </div>

                <div class="row">
                    <label class="col-sm-2 label-on-left">Email <small>*</small></label>
                    <div class="col-sm-7">
                        <div class="form-group label-floating is-empty">
                            <input class="form-control" name="email_penjahit" type="email" placeholder="name@mail.com" value="<?php echo e($data->email_penjahit); ?>" required="true"  />
                        </div>
                    </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 label-on-left">Password <small>*</small></label>
                  <div class="col-sm-7">
                      <div class="form-group label-floating is-empty">
                          <input class="form-control" name="password_penjahit" type="password" placeholder="xxxxxx" value="<?php echo e($data->password_penjahit); ?>" required="true" />
                      </div>
                  </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 label-on-left">No. Telp</label>
                  <div class="col-sm-7">
                      <div class="form-group label-floating is-empty">
                          <input class="form-control" name="telp_penjahit" type="text" placeholder="08xxxxxx" value="<?php echo e($data->telp_penjahit); ?>"  />
                      </div>
                  </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 label-on-left">Nama Toko</label>
                  <div class="col-sm-7">
                      <div class="form-group label-floating is-empty">
                          <input class="form-control" name="nama_toko" type="text" placeholder="Toko Jaya Makmur" value="<?php echo e($data->nama_toko); ?>"  />
                      </div>
                  </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 label-on-left">Keterangan Toko</label>
                  <div class="col-sm-7">
                      <div class="form-group label-floating is-empty">
                          <textarea class="form-control" rows="3" name="keterangan_toko" placeholder="<?php echo e(__('Keterangan Toko')); ?>"></textarea>
                          
                          
                      </div>
                  </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 label-on-left">Latitude</label>
                  <div class="col-sm-7">
                      <div class="form-group label-floating is-empty">
                          <input class="form-control" name="latitude_penjahit" type="text" placeholder="<?php echo e(__('Latitude')); ?>" value="<?php echo e($data->latitude_penjahit); ?>"    />
                      </div>
                  </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 label-on-left">Longitude</label>
                  <div class="col-sm-7">
                      <div class="form-group label-floating is-empty">
                          <input class="form-control" name="longitude_penjahit" type="text" placeholder="<?php echo e(__('Longitude')); ?>" value="<?php echo e($data->longitude_penjahit); ?>"    />
                      </div>
                  </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 label-on-left">Alamat</label>
                  <div class="col-sm-7">
                      <div class="form-group label-floating is-empty">
                          <input class="form-control" name="alamat_penjahit" type="text" placeholder="<?php echo e(__('Alamat')); ?>" value="<?php echo e($data->alamat_penjahit); ?>"    />
                      </div>
                  </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 label-on-left">Spesifikasi Penjahit</label>
                  <div class="col-sm-7">
                      <div class="form-group label-floating is-empty">
                          <input class="form-control" name="spesifikasi_penjahit" type="text" placeholder="<?php echo e(__('Spesifikasi Penjahit')); ?>" value="<?php echo e($data->spesifikasi_penjahit); ?>"    />
                      </div>
                  </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 label-on-left">Jangkauan Kategori Penjahit</label>
                  <div class="col-sm-7">
                      <div class="form-group label-floating is-empty">
                          <input class="form-control" name="jangkauan_kategori_penjahit" type="text" placeholder="<?php echo e(__('Jangkauan Kategori Penjahit')); ?>" value="<?php echo e($data->jangkauan_kategori_penjahit); ?>"    />
                      </div>
                  </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 label-on-left">Hari Buka</label>
                  <div class="col-sm-7 checkbox-radios">
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="hari_buka[]" value="Senin" <?php echo e((is_array(old('hari_buka')) && in_array('Senin', old('hari_buka'))) ? ' checked' : ''); ?>> Senin
                        </label>
                    </div>
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="hari_buka[]" value="Selasa" <?php echo e((is_array(old('hari_buka')) && in_array('Selasa', old('hari_buka'))) ? ' checked' : ''); ?>> Selasa
                        </label>
                    </div>
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="hari_buka[]" value="Rabu" <?php echo e((is_array(old('hari_buka')) && in_array('Rabu', old('hari_buka'))) ? ' checked' : ''); ?>> Rabu
                        </label>
                    </div>
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="hari_buka[]" value="Kamis" <?php echo e((is_array(old('hari_buka')) && in_array('Selasa', old('hari_buka'))) ? ' checked' : ''); ?>> Kamis
                        </label>
                    </div>
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="hari_buka[]" value="Jumat" <?php echo e((is_array(old('hari_buka')) && in_array('Jumat', old('hari_buka'))) ? ' checked' : ''); ?>> Jum'at
                        </label>
                    </div>
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="hari_buka[]" value="Sabtu" <?php echo e((is_array(old('hari_buka')) && in_array('Sabtu', old('hari_buka'))) ? ' checked' : ''); ?>> Sabtu
                        </label>
                    </div>
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="hari_buka[]" value="Minggu" <?php echo e((is_array(old('hari_buka')) && in_array('Minggu', old('hari_buka'))) ? ' checked' : ''); ?>> Minggu
                        </label>
                    </div>
                </div>
                  
                </div>

                <div class="row">
                  <label class="col-sm-2 label-on-left">Jam Buka</label>
                  <div class="col-sm-3">
                      <div class="form-group label-floating is-empty">
                          <input class="form-control" id="disabledInput" name="jam_buka" type="text" placeholder="<?php echo e(__('Jam Buka')); ?>" value="<?php echo e($data->jam_buka); ?>"    />
                      </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group label-floating is-empty">
                        <input class="form-control timepicker" name="jam_buka" type="time"   />
                    </div>
                </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 label-on-left">Jam Tutup</label>
                  <div class="col-sm-3">
                      <div class="form-group label-floating is-empty">
                          <input class="form-control" id="disabledInput" name="jam_tutup" type="text" placeholder="<?php echo e(__('Jam Tutup')); ?>" value="<?php echo e($data->jam_tutup); ?>"    />
                      </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="form-group label-floating is-empty">
                        <input class="form-control timepicker" name="jam_tutup" type="time"    />
                    </div>
                </div>
                </div>

    
                <div class="row">
                <label class="col-sm-2 label-on-left">Foto</label>

                    <div class="col-md-4 col-sm-4">
                      <br>
                      <img src="<?php echo e(url('img_pelanggan/'.$data->foto_penjahit)); ?>" style="width: 120px; height: 120px; border-radius: 10px;" class="card-img-top mb-3" alt="...">
                        <br>
                        <br>
                        <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                            <div class="fileinput-new thumbnail">
                                <img src="<?php echo e(url('adminpro/assets/img/image_placeholder.jpg')); ?>" alt="...">
                            </div>
                            <div class="fileinput-preview fileinput-exists thumbnail"></div>
                            <div>
                                <span class="btn btn-primary btn-round btn-file">
                                    <span class="fileinput-new">Select image</span>
                                    <span class="fileinput-exists">Change</span>
                                    <input type="file" name="foto_penjahit" />
                                </span>

                                <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                            </div>
                        </div>
                    </div> 
                </div>

                
                <div class="form-footer text-right">
                  <div class="checkbox pull-left">
                    <div class="category form-category">
                      <small>*</small> Required fields
                    </div>
                  </div>
                  <a type="button" class="btn btn-white pull-fill" href="/data_penjahit">Kembali</a>
                  <button type="submit" class="btn btn-primary pull-fill">Simpan</button>
                </div>

                
              </div>
            
              
            



          </form>  
          
          </div>
        </div>
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpro.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/penjahit/edit_data_penjahit.blade.php ENDPATH**/ ?>