<?php echo e($slot); ?>

<?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>