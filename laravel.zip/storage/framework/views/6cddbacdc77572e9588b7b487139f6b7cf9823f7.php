

<?php $__env->startSection('title', 'Data Pesanan'); ?>

<?php $__env->startSection('page_name', 'Pesanan'); ?>

<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-primary">
                <p class="card-category"></p>
                <h4 class="card-title ">Data Pesanan</h4>
                <p class="card-category"></p>
                </div>
                <div class="card-body">
                <div class="table-responsive">
                    <table id="example1" class="table">
                    <thead class=" text-primary">
                        <th class="text-center">No</th>
                        <th>ID Pesanan</th>
                        <th>Nama Pelanggan</th>
                        <th>Nama Penjahit</th>
                        <th>Tanggal Pesanan</th>
                        <th>Tanggal Pesanan Selesai</th>
                        <th>Status Pesanan</th>
                        <th class="text-right">Actions</th>
                    </thead>
                    <?php
                        $no = 1;
                    ?>
                    <tbody>   
                        <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($data_pesanan->id_pesanan); ?></td>
                                <td><?php echo e($data_pesanan->tbl_pelanggan->nama_pelanggan); ?></td>
                                <td><?php echo e($data_pesanan->tbl_penjahit->nama_penjahit); ?></td>
                                <td><?php echo e($data_pesanan->tanggal_pesanan); ?></td>
                                <td><?php echo e($data_pesanan->tanggal_pesanan_selesai); ?></td>
                                <td><?php echo e($data_pesanan->status_pesanan); ?></td>
                                
                                <td class="td-actions text-right">
                                    <form action="#" method="POST">
                                        <button type="button" rel="tooltip" class="btn btn-info">
                                            <i class="material-icons">person</i>
                                        </button>
                                        <button type="button" rel="tooltip" class="btn btn-success">
                                            <i class="material-icons">edit</i>
                                        </button>
                                        <button type="button" rel="tooltip" class="btn btn-danger">
                                            <i class="material-icons">close</i>
                                        </button>
                                    </form>
                                </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlayouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/data_pesanan.blade.php ENDPATH**/ ?>