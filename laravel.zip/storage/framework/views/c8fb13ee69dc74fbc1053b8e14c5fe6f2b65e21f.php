

<?php $__env->startSection('title', 'Edit Data Penjahit'); ?>

<?php $__env->startSection('page_name', 'Edit Data Penjahit'); ?>

<?php $__env->startSection('content'); ?>
    
<div class="content">
    <div class="container-fluid">
      
      <div class="row">
        <div class="col-md-8">
          <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title">Edit Data Penjahit</h4>
            </div>
            
            <div class="card-body">

              <?php $__currentLoopData = $penjahit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_penjahit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <form class="row" action="/data_penjahit/update/<?php echo e($data_penjahit->id_penjahit); ?>" method="post" enctype="multipart/form-data">
                  <?php echo e(csrf_field()); ?>


                <input type="hidden" name="id_penjahit" id="id_penjahit" value="<?php echo e($data_penjahit->id_penjahit); ?>">
                          

                          <div class="row">
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Nama Penjahit</label>
                                <input type="text" class="form-control" name="nama_penjahit" value="<?php echo e($data_penjahit->nama_penjahit); ?>">
                              </div>
                            </div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Email</label>
                                <input type="email" class="form-control" name="email_penjahit" value="<?php echo e($data_penjahit->email_penjahit); ?>">
                              </div>
                            </div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Password</label>
                                <input type="text" class="form-control" name="password_penjahit" value="<?php echo e($data_penjahit->password_penjahit); ?>">
                              </div>
                            </div>
                          </div>

                          <div class="row">
                            <div class="col-md-6">
                              <div class="form-group">
                                <label class="bmd-label-floating">Nama Toko</label>
                                <input type="text" class="form-control" name="nama_toko" value="<?php echo e($data_penjahit->nama_toko); ?>">
                              </div>
                            </div>
                            <div class="col-md-6">
                              <div class="form-group">
                                <label class="bmd-label-floating">Telp Toko / Penjahit</label>
                                <input type="email" class="form-control" name="telp_penjahit" value="<?php echo e($data_penjahit->telp_penjahit); ?>">
                              </div>
                            </div>
                          </div>


                          <div class="row">
                            <div class="col-md-12">
                              <div class="form-group">
                                <label class="bmd-label-floating">Alamat</label>
                                <input type="text" class="form-control" name="alamat_penjahit" value="<?php echo e($data_penjahit->alamat_penjahit); ?>">
                              </div>
                            </div>
                          </div>

                          <div class="row">
                            <div class="col-md-6">
                              <div class="form-group">
                                <label class="bmd-label-floating">Latitude</label>
                                <input type="text" class="form-control" name="latitude_penjahit" value="<?php echo e($data_penjahit->latitude_penjahit); ?>">
                              </div>
                            </div>
                            <div class="col-md-6">
                              <div class="form-group">
                                <label class="bmd-label-floating">Longitude</label>
                                <input type="email" class="form-control" name="longitude_penjahit" value="<?php echo e($data_penjahit->longitude_penjahit); ?>">
                              </div>
                            </div>
                          </div>


                          <div class="row">
                            <div class="col-md-6">
                              <div class="form-group">
                                <label class="bmd-label-floating">Spesifikasi Penjahit</label>
                                <input type="text" class="form-control" name="spesifikasi_penjahit" value="<?php echo e($data_penjahit->spesifikasi_penjahit); ?>">
                              </div>
                            </div>
                            <div class="col-md-6">
                              <div class="form-group">
                                <label class="bmd-label-floating">Jangkauan Kategori Kenjahit</label>
                                <input type="email" class="form-control" name="jangkauan_kategori_penjahit" value="<?php echo e($data_penjahit->jangkauan_kategori_penjahit); ?>">
                              </div>
                            </div>
                          </div>
   

                          <div class="row">
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Hari Buka</label>
                                <input type="text" class="form-control" name="hari_buka" value="<?php echo e($data_penjahit->hari_buka); ?>">
                              </div>
                            </div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Jam Buka</label>
                                <input type="email" class="form-control" name="jam_buka" value="<?php echo e($data_penjahit->jam_buka); ?>">
                              </div>
                            </div>
                            <div class="col-md-4">
                              <div class="form-group">
                                <label class="bmd-label-floating">Jam Tutup</label>
                                <input type="text" class="form-control" name="jam_tutup" value="<?php echo e($data_penjahit->jam_tutup); ?>">
                              </div>
                            </div>
                          </div>
                      

                          <div class="row">
                            <div class="col-md-12">
                              <div class="form-group">
                                <label>Keterangan Toko</label>
                                


                                <div class="form-group">
                                  <label class="bmd-label-floating"><?php echo e($data_penjahit->keterangan_toko); ?></label>
                                  <textarea class="form-control" rows="5" name="keterangan_toko"></textarea>
                                </div>
                              </div>
                            </div>
                          </div>
          

                          
                        
                         
                          
  
                        </div>
                      </div>
                    </div>


                    
                    <div class="col-md-4">
                      
                      <div class="form-group">
                        <label for="poster">Foto Penjahit</label>
                        <input type="file" class="" name="foto_penjahit" value="<?php echo e($data_penjahit->foto_penjahit); ?>" required>
                    </div> 

                      <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                        <div class="fileinput-new thumbnail img-raised">
                            <img src="http://style.anu.edu.au/_anu/4/images/placeholders/person_8x10.png" rel="nofollow" alt="...">
                        </div>
                        <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
                        <div>
                            <span class="btn btn-raised btn-round btn-default btn-file">
                                <span class="fileinput-new">Select image</span>
                                <span class="fileinput-exists">Change</span>
                                <input type="file" name="..." />
                            </span>
                            <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                        </div>
                    </div>
            
                        
            
                     
                    </div>

                    

            


        
      </div>


      <div>

        <button type="submit" class="btn btn-primary pull-right">Save Changes</button>
        <a class="btn btn-secondary pull-right" href="/data_penjahit">Back</a>
        
      </div>
      <div class="clearfix"></div>

</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlayouts.main_show_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/edit_data_penjahit.blade.php ENDPATH**/ ?>