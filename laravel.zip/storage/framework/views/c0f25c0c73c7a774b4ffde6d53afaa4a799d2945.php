

<?php $__env->startSection('title', 'Tambah Data'); ?>

<?php $__env->startSection('page_name', 'Tambah Data'); ?>

<?php $__env->startSection('content'); ?>
        
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8">
          <div class="card">

            <div class="card-header card-header-tabs" data-background-color="purple">
              <h4 class="card-title ">Tambah Data</h4>
            </div>
                  
            <div class="card-body">

              <form method="post" action="/data_penjahit/show/kategori/store" class="form-horizontal">
                <?php echo e(csrf_field()); ?>


                <div class="card-content ">
                          
                  <div class="row">
                    <label class="col-sm-2 label-on-left">Nama Penjahit</label>
                    <div class="col-sm-7">
                      <div class="form-group label-floating is-empty">
                        <input class="form-control" id="category" type="text" value="<?php echo e($data->nama_penjahit); ?>" disabled />
                        <input class="form-control" name="id_penjahit" id="category" type="hidden" value="<?php echo e($data->id_penjahit); ?>"  />
                      </div>
                    </div>
                  </div>  

                  <div class="row">
                    <label class="col-sm-2 label-on-left">Kategori</label>
                    <div class="col-lg-5 col-md-6 col-sm-7"> 
                      <div class="form-group" >
                        <select class="form-control selectpicker" data-style="btn btn-primary btn-round" title="Kategori" name="id_kategori">
                          <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($data_kategori->id_kategori); ?>"><?php echo e($data_kategori->nama_kategori); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div> 
                    </div>
                  </div>

                  <div class="row">
                    <label class="col-sm-2 label-on-left">Keterangan</label>
                    <div class="col-sm-7">
                      <div class="form-group label-floating is-empty">
                        <textarea class="form-control" rows="3" name="keterangan_kategori" placeholder="<?php echo e(__('Keterangan tambahan mengenai bahan')); ?>"></textarea>                                  
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <label class="col-sm-2 label-on-left">Bahan Jahit</label>
                    <div class="col-sm-7">
                      <div class="form-group label-floating is-empty">
                        <input class="form-control" name="bahan_jahit" id="category" type="text" placeholder="<?php echo e(__('Contoh : Katun')); ?>"  />                                  
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <label class="col-sm-2 label-on-left">Harga Bahan (Rp)</label>
                    <div class="col-sm-7">
                      <div class="form-group label-floating is-empty">
                        <input class="form-control" name="harga_bahan" id="category" type="number" placeholder="<?php echo e(__('100xxxx')); ?>"   />                                  
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <label class="col-sm-2 label-on-left">Ongkos Jahit (Rp)</label>
                    <div class="col-sm-7">
                      <div class="form-group label-floating is-empty">
                        <input class="form-control" name="ongkos_penjahit" id="category" type="number" placeholder="<?php echo e(__('100xxx')); ?>"   />                                  
                      </div>
                    </div>
                  </div>
  
                  <div class="row">
                    <label class="col-sm-2 label-on-left">Perkiraan Lama Waktu Pengerjaan</label>
                    <div class="col-sm-2">
                      <div class="form-group label-floating is-empty">
                        <input class="form-control" name="perkiraan_lama_waktu_pengerjaan" id="category" type="number" placeholder="<?php echo e(__('Contoh : 5')); ?>" />                                  
                      </div>
                    </div>
                  </div>

                  <div class="form-footer text-right">
                    <a type="button" class="btn btn-white pull-fill" href="/data_penjahit/show/<?php echo e($data->id_penjahit); ?>">Kembali</a>
                    <button type="submit" onclick="return confirm('Ingin menambahkan data?')" class="btn btn-primary pull-fill">Simpan</button>
                  </div>     
            
                </div>
              </form>        
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpro.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/penjahit/add_data_detail_kategori.blade.php ENDPATH**/ ?>