

<?php $__env->startSection('title', 'Data Rating'); ?>

<?php $__env->startSection('page_name', 'Data Rating'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">

                        <div class="card-header card-header-tabs" data-background-color="purple">
                            <h4 class="card-title">Data Rating</h4>
                        </div>

                    <div class="card-content">

                        <div class="table-responsive">
                            <table id="datatables" class="table table-bordered table-striped">
                
                
                                <thead class="text-primary">
                                    <th>No</th>
                                    <th>Nama Penjahit</th>
                                    <th>Kriteria 1</th>
                                    <th>Kriteria 2</th>
                                    <th>Kriteria 3</th>
                                    <th>Kriteria 4</th>
                                </thead>
                                <?php
                                    $no = 1;
                                ?>
                                <tbody>   
                                    <?php $__currentLoopData = $rating_penjahit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_penjahit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($no++); ?></td>
                                            <td><?php echo e($data_penjahit->nama_penjahit); ?></td>
                                            <td><?php echo e($data_penjahit->kriteria_1); ?></td>
                                            <td><?php echo e($data_penjahit->kriteria_2); ?></td>
                                            <td><?php echo e($data_penjahit->kriteria_3); ?></td>
                                            <td><?php echo e($data_penjahit->kriteria_4); ?></td>

                                    
                                    </form>
                                </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                    </tbody>
                
                    
                </table>
            </div>
            </div>
        </div>
        </div>
    </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpro.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/rating/data_rating.blade.php ENDPATH**/ ?>