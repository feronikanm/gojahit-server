

<?php $__env->startSection('title', 'Detail Data'); ?>

<?php $__env->startSection('page_name', 'Detail Data'); ?>

<?php $__env->startSection('content'); ?>
    

        
    <div class="content">
        <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
            <div class="card">


                <?php $__currentLoopData = $kategori_penjahit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="card-header card-header-tabs card-header-primary">
                    <div class="nav-tabs-navigation">
                      <div class="nav-tabs-wrapper">
                        <span class="nav-tabs-title" style="font-size: 1.125rem; text-shadow: 0 2px 5px rgba(33, 33, 33, 0.5); ">Detail Kategori</span>
                        <ul class="nav nav-tabs justify-content-end" data-tabs="tabs">
                          <li class="nav-item">
                            <a type="button" class="btn btn-primary" href="/data_penjahit/show/kategori/edit/<?php echo e($kategori->id_detail_kategori); ?>"><i class="material-icons">edit</i> Edit</a>
                          </li>
                          
                            

                            
                          
                        </ul>
                      </div>
                    </div>
                  </div>


                

                <div class="card-body">
                <div class="table-responsive">
                    <table id="example1" class="table table-bordered table-striped">
                    <thead class=" text-primary">
                        <th>Nama Kategori</th>
                        <th>Keterangan</th>
                        <th>Bahan Jahit</th>
                        <th>Harga Bahan</th>
                        <th>Ongkos Jahit</th>
                        <th>Perkiraan Lama Waktu Pengerjaan</th>
                        
                        
                    </thead>
                    <?php
                        $no = 1;
                    ?>
                    <tbody>   
                            <tr>
                                
                                <td><?php echo e($kategori->nama_kategori); ?></td>
                                <td><?php echo e($kategori->keterangan_kategori); ?></td>
                                <td><?php echo e($kategori->bahan_jahit); ?></td>
                                <td><?php echo e($kategori->harga_bahan); ?></td>
                                <td><?php echo e($kategori->ongkos_penjahit); ?></td>
                                <td><?php echo e($kategori->perkiraan_lama_waktu_pengerjaan); ?></td>


                                
                                    
                                    
                                
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
                </div>
            </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
            <div class="card">



                


                <div class="card-header card-header-tabs  card-header-primary">
                    <h4 class="card-title ">Detail Ukuran</h4>
                </div>

                <div class="card-body">
                <div class="table-responsive">
                    <table id="example1" class="table table-bordered table-striped">
                    <thead class=" text-primary">
                        <th>Nama Ukuran</th>
                        <th>Gambar Ukuran</th>
                        <th class="text-center">Actions</th>
                    </thead>
                    <?php
                        $no = 1;
                    ?>
                    <tbody>   
                        <?php $__currentLoopData = $ukuran_kategori_penjahit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ukuran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($ukuran->nama_ukuran); ?></td>
                                <td><?php echo e($ukuran->gambar_ukuran); ?></td>
            
                                <td class="td-actions text-center">
                                    
                                    
                                </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
                </div>
            </div>
            </div>
        </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlayouts.main_show_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/penjahit/show_ukuran_kategori.blade.php ENDPATH**/ ?>