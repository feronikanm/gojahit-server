


<?php $__env->startSection('title', 'Edit Data Kriteria'); ?>

<?php $__env->startSection('page_name', 'Edit Data Kriteria'); ?>

<?php $__env->startSection('content'); ?>
        

  <div class="content">
    <div class="container-fluid">


      <div class="row">
        <div class="col-md-8">
          <div class="card">

              <div class="card-header card-header-tabs" data-background-color="purple">
                  <h4 class="card-title ">Edit Data Kriteria</h4>
              </div>
          
                <form method="post" action="/data_kriteria/update/<?php echo e($data->id_kriteria); ?>" enctype="multipart/form-data" class="form-horizontal">
                  <?php echo e(csrf_field()); ?>



                  <div class="card-content">

                    <div class="row">
                      <label class="col-sm-2 label-on-left">Nama Kriteria</label>
                      <div class="col-sm-7">
                          <div class="form-group label-floating is-empty">
                              <input class="form-control" name="nama_utilitas" type="text" placeholder="Nama Utilitas" value="<?php echo e($data->nama_kriteria); ?>" autofocus />
                          </div>
                      </div>
                    </div>




                 

                    <div class="row">
                      <label class="col-sm-2 label-on-left">Bobot Kriteria</label>
                      <div class="col-sm-7">
                          <div class="form-group label-floating is-empty">
                              <input class="form-control" name="bobot_kriteria" type="text" placeholder="Bobot Kriteria" value="<?php echo e($data->bobot_kriteria); ?>" autofocus />
                          </div>
                      </div>
                    </div>

                    <div class="form-footer text-right">
                      <div class="checkbox pull-left">
                        <div class="category form-category">
                        </div>
                      </div>
                      <a type="button" class="btn btn-white pull-fill" href="/data_kriteria">Kembali</a>
                      <button type="submit" class="btn btn-primary pull-fill">Simpan</button>
                    </div>  
      
                  </div>                              
                </form>  
            </div>
          </div>
        </div>

        


    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpro.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/kriteria/edit_data_kriteria.blade.php ENDPATH**/ ?>