<?php $__env->startSection('title', 'Welcome'); ?>

<?php $__env->startSection('page_name', 'Welcome'); ?>

<?php $__env->startSection('content'); ?>
    


    <div class="page-header header-filter" data-parallax="true" style="background-image: url('../assets/img/city.jpg'); background-size: cover; background-position: top center;">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
             
            <?php if(Route::has('login')): ?>
                <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>" class="text-sm text-gray-700 underline">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 underline">Login</a>

                        <?php if(Route::has('register')): ?>
                            
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>    
            
          </div>
        </div>
      </div>
    </div>

    

      





  <?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlayouts.welcome_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/welcome.blade.php ENDPATH**/ ?>