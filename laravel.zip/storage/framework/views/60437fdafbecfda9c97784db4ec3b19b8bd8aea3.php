

<?php $__env->startSection('title', 'Tambah Data Kategori'); ?>

<?php $__env->startSection('page_name', 'Tambah Data Kategori'); ?>

<?php $__env->startSection('content'); ?>
        

  <div class="content">
    
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
            <div class="card">
                <div class="card-header card-header-primary">
                <p class="card-category"></p>
                <h4 class="card-title ">Tambah Data Kategori</h4>
                <p class="card-category"></p>
                </div>
                <div class="card-body">
      

                    <form>
                        <div class="form-group">
                          <label for="exampleInputEmail1">Nama Kategori</label>
                          <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama Kategori">
                        </div>
                        
                        <div class="form-group form-file-upload form-file-multiple">
                            <input type="file" multiple="" class="inputFileHidden">
                            <label for="exampleInputEmail1">Gambar</label>
                            <div class="input-group">
                                
                                <input type="text" class="form-control inputFileVisible" placeholder="Gambar Kategori">
                                <span class="input-group-btn">
                                    <button type="button" class="btn btn-fab btn-round btn-primary">
                                        <i class="material-icons">attach_file</i>
                                    </button>
                                </span>
                            </div>
                          </div>
                          
                        <button type="submit" class="btn btn-primary pull-right">Simpan</button>
                        <button type="submit" class="btn btn-secondary pull-right">Kembali</button>
                      </form>
                      

                </div>
            </div>
            </div>
        </div>
        </div>

  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlayouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/add_data_kategori.blade.php ENDPATH**/ ?>