<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('page_name', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    

<style>
    .elevation-2 {
      box-shadow: 0 3px 6px rgba(0, 0, 0, 0.16), 0 3px 6px rgba(0, 0, 0, 0.23) !important;
    }

    .elevation-3 {
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23) !important;
    }

    .img-circle {
      border-radius: 50%;
    }

    .brand-image {
      background-color:rgba(255, 255, 255, 0.12);
    }

    h4 {
      text-shadow: 2px 2px #08080871;
    }

  </style>

  <div class="page-header header-filter" style="background-image: url('../assets/img/city.jpg'); background-size: cover; background-position: top center;">
    <div class="container mt-5">
      <div class="row mt-5">
        <div class="col-lg-6 col-md-6 ml-auto mr-auto mt-5">
          <div class="card card-login">
              <div class="card-header card-header-primary text-center">
                <hr>
                
                <a href="/"><h4 class="card-title">Login Admin GoJahit</h4></a>
                <hr>
                
                <div class="social-line">
                  <a href="https://github.com/feronikanm" target="_blank" class="simple-text logo-normal">
                    <img src="<?php echo e(url('assets/img/icon_mesin_jahit.png')); ?>" alt="Go Jahit Logo" class="brand-image img-circle elevation-3" style="opacity: 1.0" width="140" height="140">
                  </a>
                </div>
                <br>
                
              </div>


              

              <div class="card-body">
                <form method="POST" action="<?php echo e(route('login')); ?>">

                  <?php echo csrf_field(); ?>

                  <div class="card-body">

                    <div class="form-group">
                      <div class="row">
                          <label for="email" class="col-sm-4 col-form-label text-md-right"><i class="material-icons">account_circle</i></label>
                          <div class="col-sm-6">
                        
                          <input id="email" type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Username" autofocus>
                          

                              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <span class="invalid-feedback" role="alert">
                                      <strong><?php echo e($message); ?></strong>
                                  </span>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="row">
                            <label for="password" class="col-sm-4 col-form-label text-md-right"><i class="material-icons">lock_outline</i></label>
                            <div class="col-sm-6">
                          
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                  </div>

                  


                  <div class="form-group row mb-0">
                    <div class="mr-auto ml-auto">
                        <button type="submit" class="btn btn-primary btn-wd">
                            <?php echo e(__('Login')); ?>

                        </button>

                        <?php if(Route::has('password.request')): ?>
                            
                        <?php endif; ?>
                      </div>
                  </div>
            </form>
          </div>


          </div>
        </div>
      </div>
    </div>
    <footer class="footer">
      <div class="container">
        
        <div class="copyright float-right">
          GoJahit
          &copy;
          <script>
            document.write(new Date().getFullYear())
          </script> Develop with <i class="material-icons">favorite</i> by
          <a href="https://github.com/feronikanm" target="_blank">feronikanm</a>
        </div>
      </div>
    </footer>
  </div>





<?php $__env->stopSection(); ?>




<?php echo $__env->make('adminlayouts.welcome_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/auth/login.blade.php ENDPATH**/ ?>