

<?php $__env->startSection('title', 'Data Kategori'); ?>

<?php $__env->startSection('page_name', 'Kategori'); ?>

<?php $__env->startSection('content'); ?>


    <div class="content">
        <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-primary">
                <p class="card-category"></p>
                <h4 class="card-title ">Data Kategori</h4>
                <p class="card-category"></p>
                </div>
                <div class="card-body">
                <div class="table-responsive">
                    <table id="example1" class="table">
                    <thead class=" text-primary">
                        <th class="text-center">No</th>
                        <th class="text-center">ID Kategori</th>
                        <th>Nama Kategori</th>
                        <th class="text-center">Gambar Kategori</th>
                        <th class="text-right">Actions</th>
                    </thead>
                    <?php
                        $no = 1;
                    ?>
                    <tbody>   
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center">#</td>
                                <td><?php echo e($data_kategori->id_kategori); ?></td>
                                <td><?php echo e($data_kategori->nama_kategori); ?></td>
                                <td class="text-center"><?php echo e($data_kategori->gambar_kategori); ?></td>
                                
                                <td class="td-actions text-right">
                                    <form action="#" method="POST">
                                        <button type="button" rel="tooltip" class="btn btn-info">
                                            <i class="material-icons">person</i>
                                        </button>
                                        <button type="button" rel="tooltip" class="btn btn-success">
                                            <i class="material-icons">edit</i>
                                        </button>
                                        <button type="button" rel="tooltip" class="btn btn-danger">
                                            <i class="material-icons">close</i>
                                        </button>
                                    </form>
                                </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlayouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/data-kategori.blade.php ENDPATH**/ ?>