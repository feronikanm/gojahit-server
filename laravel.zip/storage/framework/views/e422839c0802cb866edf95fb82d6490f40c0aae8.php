<div class="sidebar" data-active-color="purple" data-background-color="black" data-image="<?php echo e(url('adminpro/assets/img/sidebar-1.jpg')); ?>">
    <!--
Tip 1: You can change the color of active element of the sidebar using: data-active-color="purple | blue | green | orange | red | rose"
Tip 2: you can also add an image using data-image tag
Tip 3: you can change the color of the sidebar with data-background-color="white | black"
-->
    <div class="logo">
        <a href="https://github.com/feronikanm" target="_blank" class="simple-text">
            G o - J a h i t
        </a>
    </div>
    <div class="logo logo-mini">
        <a href="https://github.com/feronikanm" target="_blank" class="simple-text">
            GO
        </a>
    </div>
    <div class="sidebar-wrapper">
        <div class="user">
            <div class="photo">
                <img src="<?php echo e(url('adminpro/assets/img/icon_mesin_jahit.png')); ?>" />
            </div>
            <div class="info">
                <a data-toggle="collapse" href="#collapseExample" class="collapsed">
                    <br>
                    <?php echo e(Auth::user()->name); ?>

                    
                </a>
                
            </div>
        </div>
        <ul class="nav">
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>">
                    <i class="material-icons">dashboard</i>
                    <p>Dokumentasi</p>
                </a>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(url('/data_pelanggan')); ?>">
                    <i class="material-icons">person</i>
                    <p>Data Pelanggan</p>
                </a>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(url('/data_penjahit')); ?>">
                    <i class="material-icons">local_library</i>
                    <p>Data Penjahit</p>
                </a>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(url('/data_kategori')); ?>">
                    <i class="material-icons">timeline</i>
                    <p>Data Kategori</p>
                </a>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(url('/data_detail_kategori')); ?>">
                    <i class="material-icons">apps</i>
                    <p>Data Detail Kategori</p>
                </a>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(url('/data_ukuran')); ?>">
                    <i class="material-icons">content_paste</i>
                    <p>Data Ukuran</p>
                </a>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(url('/data_pesanan')); ?>">
                    <i class="material-icons">shopping_cart</i>
                    <p>Data Pesanan</p>
                </a>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(url('/data_ukuran_detail_pesanan')); ?>">
                    <i class="material-icons">layers</i>
                    <p>Data Ukuran Pesanan</p>
                </a>  
            </li>

            

            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(url('/data_kriteria')); ?>">
                    <i class="material-icons">widgets</i>
                    <p>Data Kriteria</p>
                </a>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(url('/data_rating')); ?>">
                    <i class="material-icons">stars</i>
                    <p>Data Rating</p>
                </a>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(url('/data_nilai')); ?>">
                    <i class="material-icons">bubble_chart</i>
                    <p>Data Penilaian</p>
                </a>
            </li>

            



            





        </ul>
    </div>
</div>


<?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/adminpro/sidebar.blade.php ENDPATH**/ ?>