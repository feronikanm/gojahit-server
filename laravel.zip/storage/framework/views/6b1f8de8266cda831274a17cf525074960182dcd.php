


<?php $__env->startSection('title', 'Data Detail Pesanan'); ?>

<?php $__env->startSection('page_name', 'Data Detail Pesanan'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="content">
        <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
            <div class="card">

                

                <div class="card-header card-header-tabs" data-background-color="purple">
                    <h4 class="card-title">Data Detail Pesanan</h4>
                </div>

                
                <div class="card-content">

                <div class="table-responsive">

                    
                    <table id="datatables" class="table table-bordered table-striped">
                    
                        <thead class=" text-primary">
                        <th class="text-center">No</th>
                        <th>ID Pesanan</th>
                        <th>Catatan</th>
                        <th>Kategori</th>
                        <th>Bahan</th>
                        <th>Asal Bahan</th>
                        <th>Panjang</th>
                        <th>Lebar</th>
                        <th>Status Bahan</th>
                        <th>Harga</th>
                        <th>Ongkos Penjahit</th>
                        <th>Jumlah</th>
                        <th>Biaya</th>
                        <th>Total Biaya</th>
                        <th class="text-right">Actions</th>
                    </thead>
                    <?php
                        $no = 1;
                    ?>
                    <tbody>   
                        <?php $__currentLoopData = $detail_pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_detail_pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($no++); ?></td>
                                <td><?php echo e($data_detail_pesanan->tbl_pesanan->id_pesanan); ?></td>
                                <td><?php echo e($data_detail_pesanan->catatan_pesanan); ?></td>
                                <td><?php echo e($data_detail_pesanan->kategori); ?></td>
                                <td><?php echo e($data_detail_pesanan->bahan_jahit); ?></td>
                                <td><?php echo e($data_detail_pesanan->asal_bahan); ?></td>
                                <td><?php echo e($data_detail_pesanan->panjang_bahan); ?></td>
                                <td><?php echo e($data_detail_pesanan->lebar_bahan); ?></td>
                                <td><?php echo e($data_detail_pesanan->status_bahan); ?></td>
                                <td><?php echo e($data_detail_pesanan->harga_bahan); ?></td>
                                <td><?php echo e($data_detail_pesanan->ongkos_penjahit); ?></td>
                                <td><?php echo e($data_detail_pesanan->jumlah_jahitan); ?></td>
                                <td><?php echo e($data_detail_pesanan->biaya_jahitan); ?></td>
                                <td><?php echo e($data_detail_pesanan->total_biaya); ?></td>
                                
                                <td class="td-actions text-right">
                                    <form action="#" method="POST">
                                        <button type="button" rel="tooltip" class="btn btn-info">
                                            <i class="material-icons">person</i>
                                        </button>
                                        <button type="button" rel="tooltip" class="btn btn-success">
                                            <i class="material-icons">edit</i>
                                        </button>
                                        <button type="button" rel="tooltip" class="btn btn-danger">
                                            <i class="material-icons">close</i>
                                        </button>
                                    </form>
                                </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpro.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KULIAH\BISMILLAH_SKRIPSI\PROGRAM\RestAPI\resources\views/detail_pesanan/data_detail_pesanan.blade.php ENDPATH**/ ?>