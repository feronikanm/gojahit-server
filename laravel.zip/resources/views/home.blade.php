@extends('adminlayouts.main')

@section('title', 'Home')

@section('page_name', 'Home')

@section('content')
    


<div class="content">
    <div class="container-fluid">
      


      
    </div>
  </div>
  
  @endsection