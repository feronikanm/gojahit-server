<footer class="footer">
    <div class="container-fluid">
      <div class="copyright float-right">
        GoJahit 
        
        &copy;
        <script>
          document.write(new Date().getFullYear())
        </script> Develop 
        {{-- with <i class="material-icons">favorite</i>  --}}
        by
        <a href="https://github.com/feronikanm" target="_blank">FNM</a>
      </div>
    </div>
  </footer>

{{-- 
  <footer class="footer">
    <div class="container">
      
      <div class="copyright float-right">
        GoJahit
        &copy;
        <script>
          document.write(new Date().getFullYear())
        </script> Develop with <i class="material-icons">favorite</i> by
        <a href="https://github.com/feronikanm" target="_blank">feronikanm</a>
      </div>
    </div>
  </footer> --}}